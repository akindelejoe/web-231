document.getElementById("blanket-link").onclick = function () {
  document.getElementById("plantDescription").textContent = 
    "This plant is called Blanket. It's beautiful and adds color to the garden.";
};

document.getElementById("bluestem-link").onclick = function () {
  document.getElementById("Description").textContent = 
    "This is called Bluestem. A strong plant and a good addition to the garden.";
};

document.getElementById("rugosa-link").onclick = function () {
  document.getElementById("Details").textContent = 
    "Rugosa! It's unique and vibrant!";
};

  

  
